// 1. Selectăm elementele necesare din DOM
const inputActivitate = document.getElementById('inputActivitate');
const btnAdauga = document.getElementById('btnAdauga');
const listaActivitati = document.querySelector('ul');

// 2. Definim tabloul de șiruri pentru lunile anului în limba română
const luniAn = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", 
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

// 3. Adăugăm ascultătorul de eveniment pe buton
btnAdauga.addEventListener('click', function() {
    
    // Citim valoarea din input și eliminăm spațiile goale de la început/sfârșit
    const textActivitate = inputActivitate.value.trim();

    // Verificăm dacă textul nu este gol
    if (textActivitate !== "") {
        
        // Creăm noul element de listă (li)
        const elementNou = document.createElement('li');

        // Obținem data curentă
        const dataCurenta = new Date();
        const zi = dataCurenta.getDate();
        const lunaIndex = dataCurenta.getMonth(); // Returnează 0-11
        const an = dataCurenta.getFullYear();

        // Obținem numele lunii din tabloul nostru
        const numeLuna = luniAn[lunaIndex];

        // Construim textul final: Activitate – adăugată la: ZZ Luna AAAA
        const textFinal = `${textActivitate} – adăugată la: ${zi} ${numeLuna} ${an}`;

        // Atribuim textul elementului li
        elementNou.textContent = textFinal;

        // Adăugăm elementul în listă
        listaActivitati.appendChild(elementNou);

        // Golim câmpul de input pentru o nouă introducere
        inputActivitate.value = "";
    } else {
        alert("Te rog să introduci o activitate!");
    }
});