// Selectăm elementele necesare
const containerDetalii = document.getElementById('detalii');
const spanData = document.getElementById('dataProdus');
const btnDetalii = document.getElementById('btnDetalii');

// Tablou cu lunile anului în limba română
const luniAn = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", 
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

// --- LA ÎNCĂRCAREA PAGINII ---

// 1. Ascundem secțiunea de detalii inițial
containerDetalii.classList.add('ascuns');

// 2. Setăm data curentă
const dataCurenta = new Date();
const zi = dataCurenta.getDate();
const lunaText = luniAn[dataCurenta.getMonth()];
const an = dataCurenta.getFullYear();

// Injectăm data formatată (ex: 25 Noiembrie 2025)
spanData.textContent = `${zi} ${lunaText} ${an}`;

// --- LA CLICK PE BUTON ---

btnDetalii.addEventListener('click', function() {
    // 1. Comutăm vizibilitatea (adăugăm/scoatem clasa 'ascuns')
    containerDetalii.classList.toggle('ascuns');

    // 2. Modificăm textul butonului în funcție de stare
    if (containerDetalii.classList.contains('ascuns')) {
        // Dacă are clasa 'ascuns', înseamnă că nu se vede -> textul devine "Afișează"
        btnDetalii.textContent = "Afișează detalii";
    } else {
        // Dacă NU are clasa 'ascuns', înseamnă că se vede -> textul devine "Ascunde"
        btnDetalii.textContent = "Ascunde detalii";
    }
});